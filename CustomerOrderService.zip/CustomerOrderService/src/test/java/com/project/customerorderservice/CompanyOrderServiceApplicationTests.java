package com.project.customerorderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyOrderServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
