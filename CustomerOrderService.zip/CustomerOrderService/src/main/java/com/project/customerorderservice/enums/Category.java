package com.project.customerorderservice.enums;

public enum Category {
    REGULAR,
    GOLD,
    PLATINUM
}
