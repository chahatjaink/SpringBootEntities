package com.project.customerorderservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerOrderServiceApplication {


    public static void main(String[] args) {
        SpringApplication.run(CustomerOrderServiceApplication.class, args);
    }

}
